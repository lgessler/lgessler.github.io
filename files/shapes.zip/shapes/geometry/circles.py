from math import pi

def circle_area(r):
    return pi * r * r