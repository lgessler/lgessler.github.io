def rectangle_area(w, h):
    return w * h