from geometry.rectangles import rectangle_area
from geometry.circles import circle_area

print(rectangle_area(5, 3))  # 15
print(circle_area(3))  # 28.27